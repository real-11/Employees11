package com.employees1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Employees1Application {

	public static void main(String[] args) {
		SpringApplication.run(Employees1Application.class, args);
	}

}
